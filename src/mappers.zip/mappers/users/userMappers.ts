import { Gender } from "@/services/dtos/enums";
import type { RoleListResponseDto, UserBasicResponseDto, UserDetailResponseDto, UserListResponseDto } from "@/services/dtos/responseDtos/userResponseDtos";
import type {
    UserBasicModel,
    UserListModel,
    UserCreateModel,
    UserDetailModel,
    UserUpdateModel,
    RoleOptionsModel,
    RoleModel,
    UserPasswordChangeModel,
    UserPasswordResetModel, UpcomingBirthdayUserListModel, UpcomingBirthdayUserModel, JoinedRecentlyUserListModel
} from '@/models/userModels'
import { useDateTimeUtility } from "@/utilities/dateTimeUtility";
import { usePhotoUtility } from "@/utilities/photoUtility";
import { useAvatarUtility } from "@/utilities/avatarUtility";
import type {
    UserCreateRequestDto,
    UserListRequestDto,
    UserUpdateRequestDto,
    UserPasswordChangeRequestDto,
    UserPasswordResetRequestDto } from "@/services/dtos/requestDtos/userRequestDtos";

const dateTimeUtility = useDateTimeUtility();
const photoUtility = usePhotoUtility();
const avatarUtility = useAvatarUtility();

export function useUserDetailMapper() {
    function fromResponseDto(responseDto: UserDetailResponseDto): UserDetailModel {
        return {
            id: responseDto.id,
            userName: responseDto.userName,
            personalInformation: responseDto.personalInformation != null
                ? {
                    firstName: responseDto.personalInformation.firstName,
                    middleName: responseDto.personalInformation.middleName ?? "",
                    lastName: responseDto.personalInformation.lastName,
                    fullName: responseDto.personalInformation.fullName,
                    gender: responseDto.personalInformation.gender,
                    birthday: dateTimeUtility
                        .toDisplayDate(responseDto.personalInformation.birthday)
                        ?? "",
                    phoneNumber: responseDto.personalInformation.phoneNumber ?? "",
                    email: responseDto.personalInformation.email ?? "",
                    avatarUrl: responseDto.personalInformation.avatarUrl != null
                        ? photoUtility
                            .getPhotoUrl(responseDto.personalInformation.avatarUrl)
                        : avatarUtility
                            .getAvatarUrlByFullName(responseDto.personalInformation.fullName),
                } : null,
            userInformation: responseDto.userInformation != null
                ? {
                    createdDateTime: dateTimeUtility
                        .toDisplayDateTime(responseDto.userInformation.createdDateTime)!,
                    updatedDateTime: dateTimeUtility
                        .toDisplayDateTime(responseDto.userInformation.updatedDateTime)
                        ?? "",
                    joiningDate: responseDto.userInformation.joiningDate ?? "",
                    note: responseDto.userInformation.note ?? "",
                    role: {
                        id: responseDto.userInformation.role.id,
                        name: responseDto.userInformation.role.name,
                        displayName: responseDto.userInformation.role.displayName,
                        powerLevel: responseDto.userInformation.role.powerLevel,
                        permissions: responseDto.userInformation.role.permissions
                    }
                } : null,
        };
    }

    return { fromResponseDto };
}

export function useUserCreateMapper() {
    function toRequestDto(model: UserCreateModel): UserCreateRequestDto {
        return {
            userName: model.userName,
            password: model.password,
            confirmationPassword: model.confirmationPassword,
            personalInformation: {
                firstName: model.personalInformation!.firstName,
                middleName: model.personalInformation!.middleName || null,
                lastName: model.personalInformation!.lastName,
                gender: model.personalInformation!.gender,
                birthday: model.personalInformation?.birthday != null
                    ? dateTimeUtility.toDateISOString(model.personalInformation.birthday)
                    : null,
                phoneNumber: model.personalInformation!.phoneNumber || null,
                email: model.personalInformation!.email || null,
                avatarFile: model.personalInformation!.avatarFile || null,
                avatarChanged: true
            },
            userInformation: {
                joiningDate: model.userInformation?.joiningDate != null
                    ? dateTimeUtility.toDateISOString(model.userInformation.joiningDate)
                    : null,
                note: model.userInformation!.note || null,
                role: { name: model.userInformation!.role!.name }
            }
        }
    }

    function fromDefault(): UserCreateModel {
        return {
            id: 0,
            userName: "",
            password: "",
            confirmationPassword: "",
            personalInformation: {
                firstName: "",
                middleName: "",
                lastName: "",
                gender: Gender.Male,
                birthday: "",
                phoneNumber: "",
                email: "",
                avatarUrl: null,
                avatarFile: null,
                avatarChanged: false,
            },
            userInformation: {
                note: "",
                joiningDate: new Date().toISOString().split("T", 1)[0],
                role: null
            }
        };
    }

    return { toRequestDto, fromDefault };
}

export function useUserUpdateMapper() {
    function toRequestDto(model: UserUpdateModel): UserUpdateRequestDto {
        return {
            personalInformation: {
                firstName: model.personalInformation!.firstName,
                middleName: model.personalInformation!.middleName || null,
                lastName: model.personalInformation!.lastName,
                gender: model.personalInformation!.gender,
                birthday: model.personalInformation?.birthday != null
                    ? dateTimeUtility.toDateISOString(model.personalInformation.birthday)
                    : null,
                phoneNumber: model.personalInformation!.phoneNumber || null,
                email: model.personalInformation!.email || null,
                avatarFile: model.personalInformation!.avatarFile || null,
                avatarChanged: model.personalInformation!.avatarChanged || false,
            },
            userInformation: {
                joiningDate: model.userInformation?.joiningDate != null
                    ? dateTimeUtility.toDateISOString(model.userInformation.joiningDate)
                    : null,
                role: model.userInformation!.role,
                note: model.userInformation!.note
            }
        };
    }

    function fromResponseDto(userId: number, responseDto: UserDetailResponseDto): UserUpdateModel {
        return {
            id: userId,
            personalInformation: responseDto.personalInformation != null
                ? {
                    firstName: responseDto.personalInformation.firstName,
                    middleName: responseDto.personalInformation.middleName ?? "",
                    lastName: responseDto.personalInformation.lastName,
                    gender: responseDto.personalInformation.gender,
                    birthday: responseDto.personalInformation.birthday ?? new Date().toISOString(),
                    phoneNumber: responseDto.personalInformation.phoneNumber ?? "",
                    email: responseDto.personalInformation.email ?? "",
                    avatarUrl: responseDto.personalInformation.avatarUrl != null
                        ? photoUtility.getPhotoUrl(responseDto.personalInformation.avatarUrl)
                        : avatarUtility.getAvatarUrlByFullName(responseDto.personalInformation.fullName),
                    avatarFile: null,
                    avatarChanged: false,
                } : null,
            userInformation: responseDto.userInformation != null
                ? {
                    joiningDate: responseDto.userInformation.joiningDate,
                    note: responseDto.userInformation.note ?? "",
                    role: {
                        id: responseDto.userInformation.role.id,
                        name: responseDto.userInformation.role.name,
                        displayName: responseDto.userInformation.role.displayName,
                        powerLevel: responseDto.userInformation.role.powerLevel,
                        permissions: responseDto.userInformation.role.permissions
                    }
                } : null
        };
    }

    function fromDefault(): UserUpdateModel {
        return {
            id: 0,
            personalInformation: {
                firstName: "",
                middleName: "",
                lastName: "",
                gender: Gender.Male,
                birthday: "",
                phoneNumber: "",
                email: "",
                avatarUrl: null,
                avatarFile: null,
                avatarChanged: false,
            },
            userInformation: {
                joiningDate: "",
                note: "",
                role: null
            }
        }
    }

    return { toRequestDto, fromResponseDto, fromDefault };
}

export function useUpcomingBirthdayUserListMapper() {
    function fromResponseDto(responseDto: UserListResponseDto): UpcomingBirthdayUserListModel {
        return {
            results: responseDto.results ?
                responseDto.results.map<UpcomingBirthdayUserModel>(u => {
                    const birthdate = new Date(u.birthday!);
                    let daysLeftToBirthday: string =`${birthdate.getDate()}/${birthdate.getMonth}`;
                    if (birthdate.getDate() === new Date().getDate()) {
                        daysLeftToBirthday = "Hôm nay";
                    }

                    return {
                        id: u.id,
                        userName: u.userName,
                        firstName: u.firstName,
                        middleName: u.middleName,
                        lastName: u.lastName,
                        fullName: u.fullName,
                        gender: u.gender,
                        birthday: dateTimeUtility.toDisplayDate(u.birthday),
                        joiningDate: dateTimeUtility.toDisplayDate(u.joiningDate),
                        avatarUrl: u.avatarUrl != null
                          ? photoUtility.getPhotoUrl(u.avatarUrl)
                          : avatarUtility.getAvatarUrlByFullName(u.fullName),
                        role: {
                            id: u.role.id,
                            name: u.role.name,
                            displayName: u.role.displayName,
                        },
                        daysLeftToBirthday: daysLeftToBirthday
                    }
            }) : null
        };
    }

    return { fromResponseDto };
}

export function useJoinedRecentlyUserListMapper() {
    function fromResponseDto(responseDto: UserListResponseDto): JoinedRecentlyUserListModel {
        return {
            results: responseDto.results ?
                responseDto.results.map<UserBasicModel>(u => {
                    let joiningDateText = "";
                    const joiningDate = new Date(u.joiningDate!);
                    if (joiningDate.getDate() === new Date().getDate()) {
                        joiningDateText = "Hôm nay";
                    }

                    return {
                        id: u.id,
                        userName: u.userName,
                        firstName: u.firstName,
                        middleName: u.middleName,
                        lastName: u.lastName,
                        fullName: u.fullName,
                        gender: u.gender,
                        birthday: dateTimeUtility.toDisplayDate(u.birthday),
                        joiningDate: dateTimeUtility.toDisplayDate(u.joiningDate),
                        avatarUrl: u.avatarUrl != null
                          ? photoUtility.getPhotoUrl(u.avatarUrl)
                          : avatarUtility.getAvatarUrlByFullName(u.fullName),
                        role: {
                            id: u.role.id,
                            name: u.role.name,
                            displayName: u.role.displayName,
                        },
                        daysLeftToBirthday: joiningDateText
                    }
            }) : null
        };
    }

    return { fromResponseDto }
}

export function useUserBasicMapper() {
    function fromResponseDto(responseDto: UserBasicResponseDto): UserBasicModel {
        return {
            id: responseDto.id,
            userName: responseDto.userName,
            firstName: responseDto.firstName,
            middleName: responseDto.middleName,
            lastName: responseDto.lastName,
            fullName: responseDto.fullName,
            gender: responseDto.gender,
            birthday: dateTimeUtility.toDisplayDate(responseDto.birthday),
            joiningDate: dateTimeUtility.toDisplayDate(responseDto.joiningDate),
            avatarUrl: responseDto.avatarUrl != null
                ? photoUtility.getPhotoUrl(responseDto.avatarUrl)
                : avatarUtility.getAvatarUrlByFullName(responseDto.fullName),
            role: {
                id: responseDto.role.id,
                name: responseDto.role.name,
                displayName: responseDto.role.displayName,
            }
        };
    }

    return { fromResponseDto };
}

export function useUserListMapper() {
    function toRequestDto(model: UserListModel): UserListRequestDto {
        return {
            orderByAscending: model.orderByAscending,
            orderByField: model.orderByField,
            page: model.page,
            resultsPerPage: model.resultsPerPage,
            content: model.content,
            role: model.role != null ? { name: model.role.name } : null
        }
    }

    function mapToModelFromResponseDto(model: UserListModel, responseDto: UserListResponseDto): void {
        model.results = responseDto.results != null
                ? responseDto.results.map<UserBasicModel>(useUserBasicMapper().fromResponseDto)
                : null;
        model.pageCount = responseDto.pageCount;
    }

    return { toRequestDto, mapToModelFromResponseDto };
}

export function useRoleOptionsMapper() {
    function fromResponseDto(responseDto: RoleListResponseDto): RoleOptionsModel {
        return {
            items: responseDto.items.map<RoleModel>(role => ({
                id: role.id,
                name: role.name,
                displayName: role.displayName
            }))
        }
    }

    return { fromResponseDto };
}

export function useUserPasswordResetMapper() {
    function toRequestDto(model: UserPasswordResetModel): UserPasswordResetRequestDto {
        return {
            newPassword: model.newPassword,
            confirmationPassword: model.confirmationPassword
        }
    }

    function fromDefault(): UserPasswordResetModel {
        return {
            newPassword: "",
            confirmationPassword: ""
        }
    }

    return { toRequestDto, fromDefault };
}

export function useUserPasswordChangeMapper() {
    function toRequestDto(model: UserPasswordChangeModel): UserPasswordChangeRequestDto {
        return {
            currentPassword: model.currentPassword,
            newPassword: model.newPassword,
            confirmationPassword: model.confirmationPassword
        }
    }

    function fromDefault(): UserPasswordChangeModel {
        return {
            currentPassword: "",
            newPassword: "",
            confirmationPassword: ""
        }
    }

    return { toRequestDto, fromDefault };
}