import type { SupplyItemRequestDto } from "@/services/dtos/requestDtos/supplyItemRequestDtos";
import type { SupplyItemResponseDto } from "@/services/dtos/responseDtos/supplyItemResponseDtos";
import type { SupplyItemModel } from "@/models/supplyItemModels";
import { usePhotoUtility } from "@/utilities/photoUtility";

const photoUtility = usePhotoUtility();

export function useSupplyItemMapper() {
    return {
        fromResponseDto(responseDto: SupplyItemResponseDto): SupplyItemModel {
            return {
                id: responseDto.id,
                amount: responseDto.amount,
                vatFactor: responseDto.vatFactor,
                suppliedQuantity: responseDto.suppliedQuantity,
                product: {
                    id: responseDto.product.id,
                    name: responseDto.product.name,
                    unit: responseDto.product.unit,
                    price: responseDto.product.price,
                    thumbnailUrl: responseDto.product.thumbnailUrl
                        ? photoUtility.getPhotoUrl(responseDto.product.thumbnailUrl)
                        : photoUtility.getPhotoUrl("/images/default.jpg")
                },
                hasBeenChanged: false,
                hasBeenDeleted: false
            }
        },

        toRequestDto(model: SupplyItemModel): SupplyItemRequestDto {
            return {
                id: model.id,
                amount: model.amount,
                vatFactor: model.vatFactor,
                suppliedQuantity: model.suppliedQuantity,
                productId: model.product.id,
                hasBeenChanged: model.hasBeenChanged,
                hasBeenDeleted: model.hasBeenDeleted
            }
        }
    }
}