import { usePhotoUtility } from "@/utilities/photoUtility";
import type {
    ProductListRequestDto,
    ProductUpsertRequestDto } from "@/services/dtos/requestDtos/productRequestDtos";
import type {
    ProductBasicResponseDto, ProductListResponseDto,
    ProductDetailResponseDto } from "@/services/dtos/responseDtos/productResponseDtos";
import type {
    ProductBasicModel,
    ProductDetailModel,
    ProductListModel, 
    ProductUpsertModel } from "@/models/productModels";
import { useDateTimeUtility } from "@/utilities/dateTimeUtility";

const photoUtility = usePhotoUtility();
const dateTimeUtility = useDateTimeUtility();

export function useProductListMapper() {
    function fromDefault(): ProductListModel {
        return {
            categoryName: null,
            brandId: null,
            page: 1,
            items: null,
            pageCount: 0
        }
    }

    function toRequestDto(model: ProductListModel): ProductListRequestDto {
        return {
            categoryName: model.categoryName,
            brandId: model.brandId,
            page: model.page
        }
    }

    function mapResultsFromResponseDto(model: ProductListModel, responseDto: ProductListResponseDto) {
        model.items = responseDto.items == null ? null : responseDto.items
            .map(dto => useProductBasicMapper().fromResponseDto(dto));
        model.pageCount = responseDto.pageCount;
    }

    return { fromDefault, toRequestDto, mapResultsFromResponseDto };
}

export function useProductBasicMapper() {
    function fromResponseDto(responseDto: ProductBasicResponseDto): ProductBasicModel {
        return {
            id: responseDto.id,
            name: responseDto.name,
            unit: responseDto.unit,
            price: responseDto.price,
            thumbnailUrl: responseDto.thumbnailUrl
                ? photoUtility.getPhotoUrl(responseDto.thumbnailUrl)
                : photoUtility.getPhotoUrl("/images/default.jpg")
        }
    }

    return { fromResponseDto };
}

export function useProductDetailMapper() {
    function fromResponseDto(responseDto: ProductDetailResponseDto): ProductDetailModel {
        return {
            id: responseDto.id,
            name: responseDto.name,
            description: responseDto.description ?? "",
            unit: responseDto.unit,
            price: responseDto.price,
            vatFactor: responseDto.vatFactor,
            isForRetail: responseDto.isForRetail,
            isDiscontinued: responseDto.isDiscontinued,
            createdDateTime: dateTimeUtility
                .toDisplayDateTime(responseDto.createdDateTime)!,
            updatedDateTime: dateTimeUtility
                .toDisplayDateTime(responseDto.updatedDateTime),
            thumbnailUrl: responseDto.thumbnailUrl != null
                ? photoUtility.getPhotoUrl(responseDto.thumbnailUrl)
                : photoUtility.getPhotoUrl("/images/default.jpg"),
            category: responseDto.category && {
                id: responseDto.category.id,
                name: responseDto.category.name
            },
            brand: responseDto.brand && {
                id: responseDto.brand.id,
                name: responseDto.brand.name
            },
        }
    }

    return { fromResponseDto };
}

export function useProductUpsertMapper() {
    function fromDefault(): ProductUpsertModel {
        return {
            id: 0,
            name: "",
            description: "",
            unit: "",
            price: 0,
            vatFactor: 0,
            isForRetail: true,
            isDiscontinued: false,
            thumbnailUrl: null,
            thumbnailFile: null,
            thumbnailChanged: false,
            category: null,
            brand: null
        };
    }

    function fromResponseDto(responseDto: ProductDetailResponseDto): ProductUpsertModel {
        return {
            id: responseDto.id,
            name: responseDto.name,
            description: responseDto.description ?? "",
            unit: responseDto.unit,
            price: responseDto.price,
            vatFactor: responseDto.vatFactor,
            isForRetail: responseDto.isForRetail,
            isDiscontinued: responseDto.isDiscontinued,
            thumbnailUrl: responseDto.thumbnailUrl != null
                ? photoUtility.getPhotoUrl(responseDto.thumbnailUrl)
                : photoUtility.getPhotoUrl("/images/default.jpg"),
            thumbnailFile: null,
            thumbnailChanged: false,
            category: responseDto.category && {
                id: responseDto.category.id,
                name: responseDto.category.name
            },
            brand: responseDto.brand && {
                id: responseDto.brand.id,
                name: responseDto.brand.name
            },
        }
    }

    function toRequestDto(model: ProductUpsertModel): ProductUpsertRequestDto {
        return {
            name: model.name,
            description: model.description,
            unit: model.unit,
            price: model.price,
            vatFactor: model.vatFactor,
            isForRetail: model.isForRetail,
            isDiscontinued: model.isDiscontinued,
            thumbnailFile: model.thumbnailFile,
            thumbnailChanged: model.thumbnailChanged,
            category: model.category,
            brand: model.brand == null ? null : {
                id: model.brand.id
            }
        }
    }

    return { fromDefault, fromResponseDto, toRequestDto }
}