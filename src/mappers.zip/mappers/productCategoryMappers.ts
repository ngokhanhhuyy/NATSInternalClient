import type { ProductCategoryModel, ProductCategoryListModel } from "@/models/productCategoryModels";
import type {
    ProductCategoryRequestDto,
    ProductCategoryUpsertRequestDto } from "@/services/dtos/requestDtos/productCategoryRequestDtos";
import type {
    ProductCategoryResponseDto, ProductCategoryListResponseDto
} from "@/services/dtos/responseDtos/productCategoryResponseDtos";

export function useProductCategoryMapper() {
    function fromResponseDto(responseDto: ProductCategoryResponseDto): ProductCategoryModel {
        return {
            id: responseDto.id,
            name: responseDto.name
        };
    }

    function toRequestDto(model: ProductCategoryModel): ProductCategoryRequestDto {
        return { id: model.id };
    }

    return { fromResponseDto, toRequestDto };
}

export function useProductCategoryListMapper() {
    function fromDefault(): ProductCategoryListModel {
        return {
            items: []
        };
    }

    function mapFromResponseDto(
            model: ProductCategoryListModel,
            responseDto: ProductCategoryListResponseDto): void {
        model.items = responseDto
            .items?.map(useProductCategoryMapper().fromResponseDto) || [];
    }

    return { fromDefault, mapFromResponseDto };
}

export function useProductCategoryUpsertMapper() {
    function fromDefault(): ProductCategoryModel {
        return {
            id: 0,
            name: ""
        };
    }

    function fromResponseDto(responseDto: ProductCategoryResponseDto): ProductCategoryModel {
        return {
            id: responseDto.id,
            name: responseDto.name
        };
    }

    function toRequestDto(model: ProductCategoryModel): ProductCategoryUpsertRequestDto {
        return { name: model.name };
    }

    return { fromDefault, fromResponseDto, toRequestDto };
}