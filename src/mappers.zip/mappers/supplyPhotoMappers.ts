import type { SupplyPhotoRequestDto } from "@/services/dtos/requestDtos/supplyPhotoRequestDtos";
import type { SupplyPhotoResponseDto } from "@/services/dtos/responseDtos/supplyPhotoResponseDtos";
import type { SupplyPhotoModel } from "@/models/supplyPhotoModels";
import { usePhotoUtility } from "@/utilities/photoUtility";

const photoUtility = usePhotoUtility();

export function useSupplyPhotoMapper() {
    return {
        fromResponseDto(responseDto: SupplyPhotoResponseDto): SupplyPhotoModel {
            return {
                id: responseDto.id,
                url: responseDto.url
                    ? photoUtility.getPhotoUrl(responseDto.url)
                    : photoUtility.getPhotoUrl("/images/default.jpg"),
                file: null,
                hasBeenChanged: false
            }
        },

        toRequestDto(model: SupplyPhotoModel): SupplyPhotoRequestDto {
            return {
                id: model.id,
                file: model.file,
                hasBeenChanged: model.hasBeenChanged
            }
        }
    }
}