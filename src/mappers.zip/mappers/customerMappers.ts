import { Gender } from "@/services/dtos/enums";
import type {
    CustomerListModel,
    CustomerBasicModel,
    CustomerDetailModel,
    CustomerUpsertModel } from "@/models/customerModels";
import type {
    CustomerListResponseDto,
    CustomerBasicResponseDto,
    CustomerDetailResponseDto } from "@/services/dtos/responseDtos/customerResponseDtos";
import type {
    CustomerListRequestDto,
    CustomerUpsertRequestDto } from "@/services/dtos/requestDtos/customerRequestDtos";
import { useDateTimeUtility } from "@/utilities/dateTimeUtility";
import { useAvatarUtility } from "@/utilities/avatarUtility";

export function useCustomerListMapper() {
    function mapResponseDtoToModel(
            model: CustomerListModel,
            responseDto: CustomerListResponseDto): void {
        model.pageCount = responseDto.pageCount;
        model.results = responseDto.results && responseDto.results
            .map(dto => ({
                id: dto.id,
                fullName: dto.fullName,
                nickName: dto.nickName ?? "",
                gender: dto.gender,
                birthday: useDateTimeUtility().toDateISOString(dto.birthday),
                phoneNumber: dto.phoneNumber,
                avatarUrl: useAvatarUtility().getAvatarUrlByFullName(dto.fullName)
            }));
    }

    function toRequestDto(model: CustomerListModel): CustomerListRequestDto {
        return {
            orderByField: model.orderByField,
            orderByAscending: model.orderByAscending,
            searchByContent: model.searchByContent,
            page: model.page,
            resultsPerPage: model.resultsPerPage
        };
    }

    function fromDefault(): CustomerListModel {
        return {
            orderByField: "lastName",
            orderByAscending: true,
            searchByContent: null,
            page: 1,
            resultsPerPage: 15,
            pageCount: 0,
            results: null,
            selected: null
        };
    }

    return { mapResponseDtoToModel, toRequestDto, fromDefault };
}

export function useCustomerBasicMapper() {
    function fromResponseDto(responseDto: CustomerBasicResponseDto): CustomerBasicModel {
        return {
            id: responseDto.id,
            fullName: responseDto.fullName,
            nickName: responseDto.nickName ?? "",
            gender: responseDto.gender,
            phoneNumber: responseDto.phoneNumber,
            avatarUrl: useAvatarUtility().getAvatarUrlByFullName(responseDto.fullName)
        }
    }

    return { fromResponseDto }
}

export function useCustomerDetailMapper() {
    function fromResponseDto(responseDto: CustomerDetailResponseDto): CustomerDetailModel {
        return {
            id: responseDto.id,
            firstName: responseDto.firstName,
            middleName: responseDto.middleName ?? "",
            lastName: responseDto.lastName,
            fullName: responseDto.fullName,
            nickName: responseDto.nickName ?? "",
            gender: responseDto.gender,
            birthday: useDateTimeUtility()
                .toDisplayDate(responseDto.birthday) ?? "",
            phoneNumber: responseDto.phoneNumber ?? "",
            zaloNumber: responseDto.zaloNumber ?? "",
            facebookUrl: responseDto.facebookUrl ?? "",
            email: responseDto.email ?? "",
            address: responseDto.address ?? "",
            note: responseDto.note ?? "",
            createdDateTime: useDateTimeUtility()
                .toDisplayDateTime(responseDto.createdDateTime) ?? "",
            updatedDateTime: useDateTimeUtility()
                .toDisplayDateTime(responseDto.updatedDateTime) ?? "",
            introducer: responseDto.introducer && {
                id: responseDto.introducer.id,
                fullName: responseDto.introducer.fullName,
                nickName: responseDto.introducer.nickName ?? "",
                gender: responseDto.introducer.gender,
                phoneNumber: responseDto.phoneNumber ?? "",
                avatarUrl: useAvatarUtility()
                    .getAvatarUrlByFullName(responseDto.introducer.fullName)
            },
            avatarUrl: useAvatarUtility()
                .getAvatarUrlByFullName(responseDto.fullName)
        }
    }

    return { fromResponseDto };
}

export function useCustomerUpsertMapper() {
    function fromResponseDto(responseDto: CustomerDetailResponseDto): CustomerUpsertModel {
        return {
            id: responseDto.id,
            firstName: responseDto.firstName,
            middleName: responseDto.middleName ?? "",
            lastName: responseDto.lastName,
            nickName: responseDto.nickName ?? "",
            gender: responseDto.gender,
            birthday: useDateTimeUtility()
                .toDateISOString(responseDto.birthday ?? new Date())!,
            phoneNumber: responseDto.phoneNumber ?? "",
            zaloNumber: responseDto.zaloNumber ?? "",
            facebookUrl: responseDto.facebookUrl ?? "",
            email: responseDto.email ?? "",
            address: responseDto.address ?? "",
            note: responseDto.note ?? "",
            introducerId: responseDto.introducer?.id ?? null
        }
    }

    function toRequestDto(model: CustomerUpsertModel): CustomerUpsertRequestDto {
        return {
            firstName: model.firstName || null,
            middleName: model.middleName || null,
            lastName: model.lastName || null,
            nickName: model.nickName || null,
            gender: model.gender,
            birthday: useDateTimeUtility()
                .toDateISOString(model.birthday) || null,
            phoneNumber: model.phoneNumber || null,
            zaloNumber: model.zaloNumber || null,
            facebookUrl: model.facebookUrl || null,
            email: model.email || null,
            address: model.address || null,
            note: model.note || null,
            introducerId: model.introducerId
        }
    }

    function fromDefault(): CustomerUpsertModel {
        return {
            id: 0,
            firstName: "",
            middleName: "",
            lastName: "",
            nickName: "",
            gender: Gender.Male,
            birthday: useDateTimeUtility().toDateISOString(new Date())!,
            phoneNumber: "",
            zaloNumber: "",
            facebookUrl: "",
            email: "",
            address: "",
            note: "",
            introducerId: null
        }
    }

    return { fromResponseDto, toRequestDto, fromDefault };
}