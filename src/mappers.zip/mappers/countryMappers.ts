import type { CountryRequestDto } from "@/services/dtos/requestDtos/countryRequestDtos";
import type { CountryResponseDto } from "@/services/dtos/responseDtos/countryResponseDtos";
import type { CountryModel } from "@/models/countryModels";

export function useCountryMapper() {
    function fromResponseDto(responseDto: CountryResponseDto): CountryModel {
        return {
            id: responseDto.id,
            name: responseDto.name,
            code: responseDto.code
        };
    }

    function toRequestDto(model: CountryModel): CountryRequestDto {
        return { id: model.id };
    }

    return { fromResponseDto, toRequestDto };
}