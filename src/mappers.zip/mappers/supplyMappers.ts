import type {
    SupplyListRequestDto,
    SupplyUpsertRequestDto } from "@/services/dtos/requestDtos/supplyRequestDtos";
import type { SupplyItemRequestDto } from "@/services/dtos/requestDtos/supplyItemRequestDtos";
import type { SupplyPhotoRequestDto } from "@/services/dtos/requestDtos/supplyPhotoRequestDtos";
import type {
    SupplyBasicResponseDto, SupplyListResponseDto,
    SupplyDetailResponseDto } from "@/services/dtos/responseDtos/supplyResponseDtos";
import type {
    SupplyListModel, SupplyDetailModel, SupplyUpsertModel, 
    SupplyBasicModel } from "@/models/supplyModels";
import type { SupplyItemModel } from "@/models/supplyItemModels";
import type { SupplyPhotoModel } from "@/models/supplyPhotoModels";
import { useUserBasicMapper } from "./users/userMappers";
import { usePhotoUtility } from "@/utilities/photoUtility";
import { useSupplyItemMapper } from "./supplyItemMappers";
import { useSupplyPhotoMapper } from "./supplyPhotoMappers";

const photoUtility = usePhotoUtility();

export function useSupplyBasicMapper() {
    return {
        fromResponseDto(responseDto: SupplyBasicResponseDto): SupplyBasicModel {
            return {
                id: responseDto.id,
                suppliedDateTime: responseDto.suppliedDateTime,
                totalAmount: responseDto.totalAmount,
                user: useUserBasicMapper().fromResponseDto(responseDto.user),
                firstPhotoUrl: responseDto.firstPhotoUrl != null
                    ? photoUtility.getPhotoUrl(responseDto.firstPhotoUrl)
                    : photoUtility.getPhotoUrl("/images/default.jpg")
            }
        }
    }
}

export function useSupplyListMapper() {
    return {
        fromDefault(): SupplyListModel {
            return {
                orderByAscending: true,
                orderByField: "suppliedDateTime",
                rangeFrom: "",
                rangeTo: "",
                page: 1,
                resultsPerPage: 15,
                items: [],
                pageCount: 0
            }
        },

        mapFromResponseDto(model: SupplyListModel, responseDto: SupplyListResponseDto): void {
            model.items = responseDto.items
                ? responseDto.items.map<SupplyBasicModel>(useSupplyBasicMapper().fromResponseDto)
                : [];
            model.pageCount = responseDto.pageCount;
        },

        toRequestDto(model: SupplyListModel): SupplyListRequestDto {
            return {
                orderByAscending: model.orderByAscending,
                orderByField: model.orderByField,
                rangeFrom: model.rangeFrom,
                rangeTo: model.rangeTo,
                page: model.page,
                resultsPerPage: model.resultsPerPage
            };
        }
    };
}

export function useSupplyDetailMapper() {
    return {
        fromResponseDto(responseDto: SupplyDetailResponseDto): SupplyDetailModel {
            return {
                id: responseDto.id,
                suppliedDateTime: responseDto.suppliedDateTime,
                shipmentFee: responseDto.shipmentFee,
                paidAmount: responseDto.paidAmount,
                note: responseDto.note || "",
                items: responseDto.items
                    ? responseDto.items.map<SupplyItemModel>(useSupplyItemMapper().fromResponseDto)
                    : [],
                photos: responseDto.photos
                    ? responseDto.photos.map<SupplyPhotoModel>(useSupplyPhotoMapper().fromResponseDto)
                    : [],
                user: useUserBasicMapper().fromResponseDto(responseDto.user)
            };
        }
    }
}

export function useSupplyUpsertMapper() {
    return {
        fromResponseDto(responseDto: SupplyDetailResponseDto): SupplyUpsertModel {
            return {
                id: responseDto.id,
                suppliedDateTime: responseDto.suppliedDateTime,
                shipmentFee: responseDto.shipmentFee,
                paidAmount: responseDto.paidAmount,
                note: responseDto.note || "",
                updateReason: "",
                items: responseDto.items
                    ? responseDto.items.map<SupplyItemModel>(useSupplyItemMapper().fromResponseDto)
                    : [],
                photos: responseDto.photos
                    ? responseDto.photos.map<SupplyPhotoModel>(useSupplyPhotoMapper().fromResponseDto)
                    : [],
                user: useUserBasicMapper().fromResponseDto(responseDto.user)
            };
        },

        toRequestDto(model: SupplyUpsertModel): SupplyUpsertRequestDto {
            return {
                suppliedDateTime: model.suppliedDateTime,
                shipmentFee: model.shipmentFee,
                paidAmount: model.paidAmount,
                note: model.note || null,
                updateReason: model.updateReason || null,
                items: model.items.length
                    ? model.items.map<SupplyItemRequestDto>(useSupplyItemMapper().toRequestDto)
                    : null,
                photos: model.photos.length
                    ? model.photos.map<SupplyPhotoRequestDto>(useSupplyPhotoMapper().toRequestDto)
                    : null
            }
        }
    }
}