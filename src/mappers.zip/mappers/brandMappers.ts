import type {
    BrandBasicModel, BrandUpsertModel,
    BrandListModel } from "@/models/brandModels";
import type {
    BrandBasicResponseDto, BrandListResponseDto,
    BrandDetailResponseDto } from "@/services/dtos/responseDtos/brandResponseDtos";
import { useCountryMapper } from "./countryMappers";
import type { BrandUpsertRequestDto } from "@/services/dtos/requestDtos/brandRequestDtos";
import { usePhotoUtility } from "@/utilities/photoUtility";

const photoUtility = usePhotoUtility();

export function useBrandListMapper() {
    function fromDefault(): BrandListModel {
        return { items: [] };
    }

    function mapFromResponseDto(
                model: BrandListModel,
                responseDto: BrandListResponseDto): void {
        model.items = responseDto.items
            ? responseDto.items.map(dto => useBrandBasicMapper().fromResponseDto(dto))
            : [];
    }

    return { fromDefault, mapFromResponseDto };
}

export function useBrandBasicMapper() {
    function fromResponseDto(responseDto: BrandBasicResponseDto): BrandBasicModel {
        return {
            id: responseDto.id,
            name: responseDto.name
        };
    }

    return { fromResponseDto };
}
export function useBrandUpsertMapper() {
    function fromDefault(): BrandUpsertModel {
        return {
            id: 0,
            name: "",
            website: "",
            socialMediaUrl: "",
            phoneNumber: "",
            email: "",
            address: "",
            thumbnailUrl: null,
            thumbnailFile: null,
            thumbnailChanged: false,
            country: null
        };
    }

    function fromResponseDto(responseDto: BrandDetailResponseDto): BrandUpsertModel {
        return {
            id: responseDto.id,
            name: responseDto.name,
            website: responseDto.website?.replace("https://", "") || "",
            socialMediaUrl: responseDto.socialMediaUrl?.replace("https://", "") || "",
            phoneNumber: responseDto.phoneNumber || "",
            email: responseDto.email || "",
            address: responseDto.address || "",
            thumbnailUrl: responseDto.thumbnailUrl &&
                photoUtility.getPhotoUrl(responseDto.thumbnailUrl),
            thumbnailFile: null,
            thumbnailChanged: false,
            country: responseDto.country && useCountryMapper().fromResponseDto(responseDto.country)
        }
    }

    function toRequestDto(model: BrandUpsertModel): BrandUpsertRequestDto {
        return {
            name: model.name,
            website: model.website,
            socialMediaUrl: model.socialMediaUrl,
            phoneNumber: model.phoneNumber,
            email: model.email,
            address: model.address,
            thumbnailFile: model.thumbnailFile,
            thumbnailChanged: model.thumbnailChanged,
            country: model.country && useCountryMapper().toRequestDto(model.country)
        };
    }

    return { fromDefault, fromResponseDto, toRequestDto };
}


